<?php

//Connect database from php file
$conn = new mysqli("localhost","u824831432_priya_krishna","Priya_Krishna@1234","u824831432_priya_krishna");
//-> Mysqli -> 1. Server Name (localhost/127.0.0.1); 2. Username; 3. Password; 4. Database Name

//Recieve data from client
$email = $_POST['email'];
$pwd = $_POST['password'];

//Run a query to check the credentials
$query = "SELECT * FROM users WHERE email = '$email' AND password='$pwd'";
$execute = mysqli_query($conn,$query);
//-> MySQLi_Query() -> 1. Successful Connection with database; 2. Query

//If credentials found, the return success otherwise return error
if($execute){
    echo json_encode([
            "status"=>"success"
    ]);

}else{
    echo json_encode([
            "status"=>"error"
    ]);
}

?>